-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 21, 2021 at 12:21 AM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 7.4.23

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `yazdjob`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `title`) VALUES
(1, 'اداری و مدیریت'),
(2, 'سرایداری و نظافت'),
(3, 'معماری ،عمران و ساختمانی'),
(4, 'خدمات فروشگاه و رستوران'),
(5, 'رایانه و فناوری اطلاعات'),
(6, 'مالی و حسابداری و حقوقی'),
(7, 'بازاریابی و فروش'),
(8, 'صنعتی و فنی و مهندسی'),
(9, 'آموزشی'),
(10, 'حمل و نقل'),
(11, 'درمانی و زیبایی و بهداشتی'),
(12, 'هنری و رسانه');

-- --------------------------------------------------------

--
-- Table structure for table `cities`
--

CREATE TABLE `cities` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `cities`
--

INSERT INTO `cities` (`id`, `title`) VALUES
(1, 'یزد'),
(2, 'ابركوه'),
(3, 'احمدآباد'),
(4, 'اردکان'),
(5, 'اشکذر'),
(6, 'بافق'),
(7, 'بفروئیه'),
(8, 'بهاباد'),
(9, 'تفت'),
(10, 'حمیدیا'),
(11, 'خضرآباد'),
(12, 'دیهوک'),
(13, 'رضوانشهر'),
(14, 'زارچ'),
(15, 'شاهدیه'),
(16, 'طبس'),
(17, 'عقدا'),
(18, 'مروست'),
(19, 'مهردشت'),
(20, 'مهریز'),
(21, 'میبد'),
(22, 'ندوشن'),
(23, 'نیر'),
(24, 'هرات');

-- --------------------------------------------------------

--
-- Table structure for table `contacts`
--

CREATE TABLE `contacts` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `body` text CHARACTER SET utf8mb4 NOT NULL,
  `is_seen` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(3, '2019_07_15_135757_create_posts_table', 1),
(4, '2019_10_12_170403_create_reports_table', 1),
(5, '2019_10_13_205157_create_categories_table', 1),
(6, '2019_10_13_205223_create_cities_table', 1),
(7, '2019_10_13_215243_create_reports_title_table', 1),
(8, '2019_10_21_121720_create_post_publish_price', 1),
(9, '2019_11_03_112108_create_contacts_table', 1),
(11, '2019_11_27_185101_create_payments_table', 1),
(12, '2019_12_25_115905_create_post_views_table', 1),
(13, '2020_01_09_183933_add_app_token_field_table_post_views', 1),
(14, '2020_01_09_193233_add_app_token_field_table_users', 1),
(17, '2020_01_21_193625_edit_post_views_columns', 1);

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `post_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 0,
  `amount` int(11) NOT NULL,
  `post_life` tinyint(4) NOT NULL DEFAULT 0,
  `is_emergency` tinyint(1) NOT NULL DEFAULT 0,
  `is_extended` tinyint(1) NOT NULL DEFAULT 0,
  `is_ladder` tinyint(1) NOT NULL DEFAULT 0,
  `gate` varchar(255) NOT NULL,
  `transaction_id` varchar(255) NOT NULL,
  `reference_id` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `category_id` int(10) UNSIGNED NOT NULL,
  `post_token` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `body` text CHARACTER SET utf8mb4 NOT NULL,
  `fee` int(11) NOT NULL DEFAULT 0,
  `fee_type` int(11) NOT NULL DEFAULT 0,
  `city` varchar(255) NOT NULL,
  `post_type` tinyint(4) NOT NULL DEFAULT 0,
  `view_count` int(11) NOT NULL DEFAULT 0,
  `post_life` tinyint(4) NOT NULL DEFAULT 0,
  `day_of_post_life` tinyint(4) NOT NULL DEFAULT 0,
  `is_extended` tinyint(1) NOT NULL DEFAULT 0,
  `is_enable` tinyint(1) NOT NULL DEFAULT 0,
  `is_pay` tinyint(1) NOT NULL DEFAULT 0,
  `is_emergency` tinyint(1) NOT NULL DEFAULT 0,
  `is_update` tinyint(1) NOT NULL DEFAULT 0,
  `is_delete` tinyint(1) NOT NULL DEFAULT 0,
  `is_expired` tinyint(1) NOT NULL DEFAULT 0,
  `img1` varchar(255) DEFAULT NULL,
  `img2` varchar(255) DEFAULT NULL,
  `img3` varchar(255) DEFAULT NULL,
  `published_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`id`, `user_id`, `category_id`, `post_token`, `title`, `slug`, `body`, `fee`, `fee_type`, `city`, `post_type`, `view_count`, `post_life`, `day_of_post_life`, `is_extended`, `is_enable`, `is_pay`, `is_emergency`, `is_update`, `is_delete`, `is_expired`, `img1`, `img2`, `img3`, `published_at`, `deleted_at`, `created_at`, `updated_at`) VALUES
(1, 14, 9, 'ShCSldkpP9SB9', 'دعوت به همکاری از دانش‌جویان و دانش‌آموختگان دوره دکتری رشته‌های مختلف علوم انسانی', 'دعوت-به-همکاری-از-دانش-جویان-و-دانش-آموختگان-دوره-دکتری-رشته-های-مختلف-علوم-انسانی', 'دعوت به همکاری از دانش‌جویان و دانش‌آموختگان دوره دکتری رشته‌های مختلف علوم انسانی (مدیریت، اقتصاد، جامعه‌شناسی، روانشناسی، ارتباطات و ...)\r\n\r\nاگر در زمینه‌های زبان انگلیسی و ترجمه و پژوهش و نگارش علمی، تخصص کامل دارید؛\r\nو به حوزه‌های تربیت اقتصادی و سواد مالی علاقمندید؛\r\nو البته پر از شور و انرژی و انگیزه‌اید،\r\nجای شما میان ما خالی است.\r\n\r\nبرخورداری از نمره بالا در آزمون‌های رسمی زبان انگلیسی و داشتن حداقل دو مقاله علمی-پژوهشی، ضروری است.\r\n\r\nرزومه و درخواست خود را از طریق آی‌دی تلگرام @hadinajaf یا ایمیل زیر برای ما ارسال کنید:\r\noffice.fintelligence@gmail.com', 0, 0, 'یزد', 0, 0, 30, 0, 0, 1, 1, 1, 0, 0, 0, NULL, NULL, NULL, '2021-10-20 22:06:04', NULL, '2021-10-20 22:01:24', '2021-10-20 22:01:24'),
(2, 15, 7, '7aTloDOVhcVV7', 'یک نفر خانم برای کار تبلیغ تلفنی', 'یک-نفر-خانم-برای-کار-تبلیغ-تلفنی', 'به یک نفر خانم(خوش بیان)برای کار تبلیغ تلفنی(کار در منزل) نیازمندیم.', 0, 0, 'یزد', 0, 0, 30, 0, 0, 1, 1, 1, 0, 0, 0, NULL, NULL, NULL, '2021-10-20 22:06:19', NULL, '2021-10-20 22:02:05', '2021-10-20 22:02:05'),
(3, 16, 7, 'K1fQmj8ZDdZH7', 'ویزیتور آقا', 'ویزیتور-آقا', 'شرکت پخش محصولات غذایی و بهداشتی جهت تکمیل کادر خود در استان سمنان و حومه از افراد واجد شرایط زیر دعوت به همکاری می نماید.\r\n\r\nعنوان شغلی : ویزیتور آقا\r\nتعداد: چهار نفر\r\n\r\n💢شرایط:\r\n\r\n🔹با حداقل مدرک تحصیلی دیپلم یا بالاتر\r\n🔹روابط عمومی بالا و مستعد جهت بازاریابی\r\n🔹فن بیان خوب و چهره آراسته\r\n\r\n\r\n\r\n💵حقوق ثابت+پورسانت+حق بیمه\r\n\r\n♨️متقاضیان واجد شرایط میتوانند رزومه خود را به تلگرام شماره زیر ارسال نمایند و یا جهت کسب اطلاعات بیشتر با شماره تلفن‌ زیر تماس حاصل نمایند:\r\n\r\n📞0901-0737372', 0, 0, 'زارچ', 0, 0, 30, 0, 0, 1, 1, 1, 0, 0, 0, NULL, NULL, NULL, '2021-10-20 22:06:12', NULL, '2021-10-20 22:03:04', '2021-10-20 22:03:04'),
(4, 17, 10, 'K0PGF9nEvCHn10', 'راننده', 'راننده', 'راننده پایه یک بادفترچه کار باری وکارت سلامت کار داخل شهر کمپرسی یا تریلی تایم ۷تا۵ بعدازظهرجمعه نمیتونم کارکنم\r\nکسی نیرو خواست اطلاع بده', 0, 0, 'یزد', 0, 0, 30, 0, 0, 1, 1, 0, 0, 0, 0, NULL, NULL, NULL, '2021-10-20 22:06:25', NULL, '2021-10-20 22:03:51', '2021-10-20 22:03:51'),
(5, 18, 7, 'wVegfh0Xgjri7', 'تعدادی فروشنده خانم', 'تعدادی-فروشنده-خانم', 'به تعدادی فروشنده خانم به صورت نیمه وقت نیازمندیم.\r\n\r\nشماره تماس: ۰۹۹۲۷۶۸۶۰۳۸\r\nتماس ۹ الی ۲۰', 0, 0, 'یزد', 0, 0, 30, 0, 0, 1, 1, 0, 0, 0, 0, NULL, NULL, NULL, '2021-10-20 22:06:31', NULL, '2021-10-20 22:04:39', '2021-10-20 22:04:39'),
(6, 19, 11, 'NaLbqh66vhbC11', 'نیازمند یک آرایشگر حرفه ای', 'نیازمند-یک-آرایشگر-حرفه-ای', 'آرایشگاه چهره ،نیازمند یک آرایشگر حرفه ای است ک در نبود بنده بتونه ارایشگاه رو اداره کنه اگ کسی میشناسید لطفا پیام بده ممنونم', 100000, 1, 'ابركوه', 0, 1, 30, 0, 0, 1, 1, 1, 0, 0, 0, NULL, NULL, NULL, '2021-10-20 22:06:36', NULL, '2021-10-20 22:05:48', '2021-10-20 22:05:48'),
(7, 20, 8, 'LCzp3r4gUPrG8', 'سرپرست فنی با سابقه کار مربوطه و تسلط به pm', 'سرپرست-فنی-با-سابقه-کار-مربوطه-و-تسلط-به-pm', 'شركت كاغذ نيل استخدام ميكند:\r\n\r\n*سرپرست فنی با سابقه کار مربوطه و تسلط به pm*\r\n\r\nساعت كار بصورت روزكار مي باشد\r\n\r\n✅محل مصاحبه:\r\nساعت ٨ صبح الی ۱۴ - شنبه تا چهارشنبه شهرك صنعتي فجر ميدان دوم سمت راست شرکت كاغذ نيل\r\nساعات تماس: ٨ صبح الي ١٥:٠٠ بعد از ظهر\r\nتلفن تماس: ٠٩٩٠٥٨٣١٩٠٠\r\n🔴مزايا:\r\nصبحانه - نهار - شام\r\nسبد كالا\r\nبيمه\r\nسرويس از گرمسار\r\nحقوق دهم هر برج\r\nاضافه كاري و همه مزاياي قانوني\r\n\r\nشماره تماس: ۸ - ٠٢٣٣٤٥٥٣٣٦٦', 0, 0, 'یزد', 0, 0, 30, 0, 0, 1, 1, 1, 0, 0, 0, NULL, NULL, NULL, '2021-10-20 22:11:04', NULL, '2021-10-20 22:07:25', '2021-10-20 22:07:25'),
(8, 21, 3, 'hvy8uDOf0MPB3', 'شاگرد سنگ کار', 'شاگرد-سنگ-کار', 'یک شاگرد سنگ کاری نیازمندم\r\nکسی بود تماس بگیره', 0, 0, 'اردکان', 0, 0, 30, 0, 0, 1, 1, 0, 0, 0, 0, NULL, NULL, NULL, '2021-10-20 22:11:10', NULL, '2021-10-20 22:09:36', '2021-10-20 22:09:36'),
(9, 22, 12, 'zQgWAfQ3XsWo12', 'دو خیاط ماهر جهت دوخت راسته دوز', 'دو-خیاط-ماهر-جهت-دوخت-راسته-دوز', 'به دو خیاط ماهر جهت دوخت راسته دوز در یک کارگاه سری دوزی نیازمندیم.\r\n\r\n🔺حقوق قانون کار\r\n🔺فاقد بیمه\r\n🔺دارای اضافه کار\r\n\r\n⭕️لطفا خیاط مبتدی تماس نگیرد!\r\n\r\nشماره تماس:\r\n📱 09100326344', 0, 0, 'میبد', 0, 0, 30, 0, 0, 1, 1, 0, 0, 0, 0, NULL, NULL, NULL, '2021-10-20 22:11:13', NULL, '2021-10-20 22:10:54', '2021-10-20 22:10:54'),
(10, 23, 5, 'BYpxoiZNkGw75', 'دعوت به همکاری فناوری و اطلاعات', 'دعوت-به-همکاری-فناوری-و-اطلاعات', 'استخدام نیمه وقت در شرکت معتبر \r\n\r\nزمینه فعالیت: فناوری و اطلاعات\r\n\r\nشرکت دانش بنیان\r\nبا شرایط زیر دعوت به همکاری می کند \r\n\r\nتعهد به انجام کار \r\nدر مشاغل اداری و فنی و توسعه ای\r\nبدون محدودیت سنی\r\nاستخدام از خانم ها و آقایان \r\nپرستیژ بالا\r\nامکان دور کاری \r\n\r\n**تعداد محدود**\r\n\r\nجهت همکاری لطفا رزومه خود را واتساپ ارسال کنید', 0, 0, 'یزد', 0, 0, 30, 0, 0, 1, 1, 0, 0, 0, 0, NULL, NULL, NULL, '2021-10-20 22:12:37', NULL, '2021-10-20 22:12:27', '2021-10-20 22:12:27');

-- --------------------------------------------------------

--
-- Table structure for table `post_publish_prices`
--

CREATE TABLE `post_publish_prices` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `monthly` int(11) NOT NULL,
  `weekly` int(11) NOT NULL,
  `monthly_karjoo` int(11) NOT NULL,
  `weekly_karjoo` int(11) NOT NULL,
  `emergency` int(11) NOT NULL,
  `extended` int(11) NOT NULL,
  `ladder` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `post_publish_prices`
--

INSERT INTO `post_publish_prices` (`id`, `monthly`, `weekly`, `monthly_karjoo`, `weekly_karjoo`, `emergency`, `extended`, `ladder`, `created_at`, `updated_at`) VALUES
(1, 10000, 5000, 5000, 3000, 5000, 5000, 5000, '2021-10-19 19:25:01', '2021-10-19 19:25:01');

-- --------------------------------------------------------

--
-- Table structure for table `post_views`
--

CREATE TABLE `post_views` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `post_id` int(11) NOT NULL,
  `app_token` varchar(255) DEFAULT NULL,
  `client_ip` varchar(255) NOT NULL,
  `user_agent` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `post_views`
--

INSERT INTO `post_views` (`id`, `post_id`, `app_token`, `client_ip`, `user_agent`, `created_at`, `updated_at`) VALUES
(3, 6, NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/94.0.4606.81 Safari/537.36', '2021-10-20 22:06:37', '2021-10-20 22:06:37');

-- --------------------------------------------------------

--
-- Table structure for table `reports`
--

CREATE TABLE `reports` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `post_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `body` text CHARACTER SET utf8mb4 NOT NULL,
  `is_seen` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `reports_title`
--

CREATE TABLE `reports_title` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `reports_title`
--

INSERT INTO `reports_title` (`id`, `title`) VALUES
(1, 'محتوای آگهی نامناسب هست'),
(2, 'اطلاعات تماس آگهی نادرست است'),
(3, 'میزان حقوق مشخص شده نادرست و ناعادلانه است'),
(4, 'شیوه برخورد صاحب آگهی مناسب نیست'),
(5, 'اطلاعات آگهی گمراه کننده و یا دروغ هست'),
(6, 'آگهی در دسته بندی نادرست قرار دارد'),
(7, 'دلایل دیگر');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `phone` varchar(255) NOT NULL,
  `is_admin` tinyint(1) NOT NULL DEFAULT 0,
  `post_id_marked` varchar(255) DEFAULT NULL,
  `app_token` varchar(255) DEFAULT NULL,
  `remember_token` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `phone`, `is_admin`, `post_id_marked`, `app_token`, `remember_token`, `created_at`, `updated_at`) VALUES
(4, '09162154221', 1, NULL, NULL, '2y101Ti86HQ5MCuLK8OFunjLxAKYFJXO6viwuR77ybVEpPVqP2y10FWx7Yrb6koyxElp1RLk6sx0dKsvY0XZDvRreqhe89dzJc', '2021-10-19 19:55:43', '2021-10-20 21:07:07'),
(14, '09150681023', 0, NULL, NULL, NULL, '2021-10-20 22:01:24', '2021-10-20 22:01:24'),
(15, '09198827900', 0, NULL, NULL, NULL, '2021-10-20 22:02:05', '2021-10-20 22:02:05'),
(16, '09010737372', 0, NULL, NULL, NULL, '2021-10-20 22:03:04', '2021-10-20 22:03:04'),
(17, '09226864393', 0, NULL, NULL, NULL, '2021-10-20 22:03:51', '2021-10-20 22:03:51'),
(18, '09927686038', 0, NULL, NULL, NULL, '2021-10-20 22:04:39', '2021-10-20 22:04:39'),
(19, '09381072153', 0, NULL, NULL, NULL, '2021-10-20 22:05:48', '2021-10-20 22:05:48'),
(20, '09905831900', 0, NULL, NULL, NULL, '2021-10-20 22:07:25', '2021-10-20 22:07:25'),
(21, '09197449457', 0, NULL, NULL, NULL, '2021-10-20 22:09:36', '2021-10-20 22:09:36'),
(22, '09100326344', 0, NULL, NULL, NULL, '2021-10-20 22:10:54', '2021-10-20 22:10:54'),
(23, '09130453140', 0, NULL, NULL, NULL, '2021-10-20 22:12:27', '2021-10-20 22:12:27');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cities`
--
ALTER TABLE `cities`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contacts`
--
ALTER TABLE `contacts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `post_publish_prices`
--
ALTER TABLE `post_publish_prices`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `post_views`
--
ALTER TABLE `post_views`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `reports`
--
ALTER TABLE `reports`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `reports_title`
--
ALTER TABLE `reports_title`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_phone_unique` (`phone`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `cities`
--
ALTER TABLE `cities`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `contacts`
--
ALTER TABLE `contacts`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `post_publish_prices`
--
ALTER TABLE `post_publish_prices`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `post_views`
--
ALTER TABLE `post_views`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `reports`
--
ALTER TABLE `reports`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `reports_title`
--
ALTER TABLE `reports_title`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
